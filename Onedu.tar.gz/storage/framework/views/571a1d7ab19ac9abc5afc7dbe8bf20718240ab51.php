<?php $__env->startSection('css-plus'); ?>
<link rel="stylesheet" href="/packages/assets/css/student/student-guide.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-student'); ?>
<div class="container">

  <div class="row">
    <div class="col-md-12">

      <div class="explanationCont z-depth-2">

        <h1>Examen Vocacional</h1>
        <div class="quiz-container">
          <div id="quiz"></div>
        </div>
        <button id="previous">Pregunta Anterior</button>
        <button id="next">Siguiente</button>
        <button id="submit">Enviar Examen</button>
        <div id="results"></div>

      </div>

    </div>
  </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js-plus'); ?>
<script type="text/javascript" src="/packages/assets/js/student/student-guide.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.baseStudent', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>