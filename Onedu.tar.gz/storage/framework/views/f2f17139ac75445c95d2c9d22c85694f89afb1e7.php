<?php $__env->startSection('css-plus'); ?>
<link rel="stylesheet" href="/packages/assets/css/university/newPublications.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-university'); ?>
<div class="container">
  <div class="row">
    <div class="col-md-12 contTextEditor">
      <textarea class="tinymce" id="textEditor" name="name" rows="8" cols="80"></textarea>
    </div>
  </div>
  <div class="text-right">
    <button type="button" class="btn btnSend z-depth-2" name="button">Guardar</button>
  </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js-plus'); ?>
<script type="text/javascript" src="/packages/libs/tinymce/tinymce.min.js"></script>
<script type="text/javascript" src="/packages/assets/js/university/newPublications.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.baseUniversity', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>