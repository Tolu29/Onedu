<?php $__env->startSection('css-plus'); ?>
<link rel="stylesheet" href="/packages/assets/css/student/student-profile.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-student'); ?>
<div class="container">

  <div class="row" id="firstLevelSprofile1">

    <div class="col-md-3">
      <div class="jumbotron">
        <div class="info">
          <a>INFORMACION</a>
        </div>
      </div>
    </div>

    <div class="col-md-4">
      <div class="jumbotron">
        <div class="fav">
          <a>FAVORITOS</a>
        </div>
      </div>
    </div>

    <div class="col-md-5">
      <div class="jumbotron">
        <div class="">

        </div>
      </div>
    </div>

  </div>

  <div class="row" id="firstLevelSprofile2">
    <div class="col-md-12">
      <div class="contProfile z-depth-2">

      </div>

    </div>

  </div>

  <div class="row" id="secondLevelSprofile">
    <div class="col-md-12">

    </div>
  </div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js-plus'); ?>
<script type="text/javascript" src="/packages/assets/js/student/student-profile.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.baseStudent', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>