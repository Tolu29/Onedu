<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Prospectos extends Model
{
    //
}
