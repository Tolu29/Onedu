<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CareersUniversities extends Model
{
    // protected $fillable = ['id', 'active', 'carrera_id', 'universidad_id'];
}
