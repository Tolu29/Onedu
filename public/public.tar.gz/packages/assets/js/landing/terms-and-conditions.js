$(function(){
  $("body").on('click', '#ONEDU', function(){
    window.location.href = '/'
  });
});
